keyboard controls
wasd or arrow keys to move
space to jump
1 to attack. f+1 to do a special attack.

controller controls
left stick or d pad to move
a to jump
x to attack
RT + x to do a special attack

attacks are directional, experiment a bit

this is not representative of anything yet

do give me feedback and tell me about bugs

dont expect to have fun, but chill if you do